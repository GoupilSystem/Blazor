﻿namespace Birk.Client.Bestilling.Enums
{
    public enum SøkStatus
    {
        IkkeSøkt,
        FinnesIkke,
        Finnes
    }
}
