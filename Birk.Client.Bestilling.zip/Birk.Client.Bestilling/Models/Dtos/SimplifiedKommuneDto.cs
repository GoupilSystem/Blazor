﻿namespace Birk.Client.Bestilling.Models.Dtos
{
    public class SimplifiedKommuneDto
    {
        public string Navn { get; set; }
    }
}
