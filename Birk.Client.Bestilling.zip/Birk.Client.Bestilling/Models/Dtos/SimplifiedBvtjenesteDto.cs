﻿namespace Birk.Client.Bestilling.Models.Dtos
{
    public class SimplifiedBvtjenesteDto
    {
        public string EnhetsnavnOgBydelsnavn { get; set; }
        public string[] Kommunenavns { get; set; }
    }
}
