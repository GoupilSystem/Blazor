﻿namespace Birk.Client.Bestilling.Models.Responses
{
    public class CreateBestillingItemResponse
    {
        public BestillingItem BestillingItem { get; set; } = new();
    }
}